
  # Machine Learning Progress Graph

  This is a code bundle for Machine Learning Progress Graph. The original project is available at https://www.figma.com/design/JK29RW0X8M7nI7u5bzznic/Machine-Learning-Progress-Graph.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  